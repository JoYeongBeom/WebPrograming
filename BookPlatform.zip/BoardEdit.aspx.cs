﻿using System;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Web.UI;

public partial class BoardEdit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // GridView가 처음 로드될 때 데이터를 바인딩합니다.
            BindGridView();
        }
    }

    // GridView 데이터 바인딩 메서드
    private void BindGridView()
    {
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["ASPNET"].ToString();
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            string query = "SELECT serial_no, writer, title, message, reg_date, del_flag FROM [dbo].[board] WHERE del_flag = 'N'"; // del_flag가 'N'인 게시글만 조회
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            System.Data.DataTable dt = new System.Data.DataTable();
            da.Fill(dt);

            gvBoard.DataSource = dt;
            gvBoard.DataBind();
        }
    }

    // 삭제 버튼 클릭 시 게시글을 삭제하는 메서드
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        int serialNo = Convert.ToInt32(btn.CommandArgument); // 삭제할 게시글의 serial_no

        try
        {
            // 데이터베이스에서 해당 게시글을 삭제하는 SQL 쿼리
            string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["ASPNET"].ToString();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "UPDATE [dbo].[board] SET [del_flag] = 'Y' WHERE [serial_no] = @serial_no"; // del_flag를 'Y'로 설정 (삭제됨)
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@serial_no", serialNo); // serial_no에 해당하는 게시글을 삭제 처리

                conn.Open();
                cmd.ExecuteNonQuery();
            }

            // 게시글 목록 새로 고침
            BindGridView(); // 데이터 바인딩을 위해 메서드 호출
        }
        catch (Exception ex)
        {
            // 오류 처리: 로그 기록 또는 사용자에게 오류 메시지 표시
            // 예: lblError.Text = "오류가 발생했습니다: " + ex.Message;
        }
    }

    // GridView에서 삭제 버튼을 클릭할 때 CommandArgument를 설정하는 방법 (GridView 정의에서 설정)
    protected void gvBoard_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == System.Web.UI.WebControls.DataControlRowType.DataRow)
        {
            Button btnDelete = (Button)e.Row.FindControl("btnDelete");
            if (btnDelete != null)
            {
                btnDelete.CommandArgument = DataBinder.Eval(e.Row.DataItem, "serial_no").ToString(); // CommandArgument에 serial_no 바인딩
            }
        }
    }
}