﻿document.addEventListener("DOMContentLoaded", function () {
    var bookSlider = document.getElementById("book-slider");
    var isMouseDown = false;
    var startX;
    var scrollLeft;

    // 슬라이더 초기화: 페이지 로드 시 첫 번째 책이 보이도록
    bookSlider.scrollLeft = 0;

    // 마우스 클릭 시작
    bookSlider.addEventListener("mousedown", function (e) {
        isMouseDown = true;
        startX = e.pageX - bookSlider.getBoundingClientRect().left;  // 마우스 시작 위치
        scrollLeft = bookSlider.scrollLeft;  // 현재 스크롤 위치
        bookSlider.style.cursor = "grabbing";  // 마우스 커서 변경
    });

    // 마우스 이동 (드래그 시)
    bookSlider.addEventListener("mousemove", function (e) {
        if (!isMouseDown) return;  // 마우스를 클릭하지 않으면 실행 안 됨
        var x = e.pageX - bookSlider.getBoundingClientRect().left;  // 마우스 이동 위치
        var walk = (x - startX) * 2;  // 스크롤 이동 속도 (3배 빠르게)
        bookSlider.scrollLeft = scrollLeft - walk;  // 스크롤 이동
    });

    // 마우스 버튼 뗄 때
    bookSlider.addEventListener("mouseup", function () {
        isMouseDown = false;
        bookSlider.style.cursor = "grab";  // 마우스 커서 원상복귀
    });

    // 마우스가 벗어났을 때 (마우스가 슬라이더 영역을 벗어나면 드래그 안 됨)
    bookSlider.addEventListener("mouseleave", function () {
        isMouseDown = false;
        bookSlider.style.cursor = "grab";  // 마우스 커서 원상복귀
    });
});
