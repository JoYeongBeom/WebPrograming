﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

public partial class MainPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadBooks();
        }
    }

    private void LoadBooks()
    {
        // 연결 문자열 가져오기
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["ASPNET"].ConnectionString;

        // 데이터 가져오기
        List<Book> books = new List<Book>();
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            string query = "SELECT BookID, Title, Author, ImagePath, Comment FROM Books";
            SqlCommand cmd = new SqlCommand(query, conn);
            conn.Open();

            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    books.Add(new Book
                    {
                        BookID = Convert.ToInt32(reader["BookID"]),  // BookID 값 읽어오기
                        Title = reader["Title"].ToString(),
                        Author = reader["Author"].ToString(),
                        ImagePath = reader["ImagePath"].ToString(),
                        Comment = reader["Comment"].ToString()
                    });
                }
            }
        }

        // Repeater에 데이터 바인딩
        BooksRepeater.DataSource = books;
        BooksRepeater.DataBind();
    }

    public class Book
    {
        public int BookID { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string ImagePath { get; set; }
        public string Comment { get; set; }
    }
}