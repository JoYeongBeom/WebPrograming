﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class AdminPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        // 페이지가 처음 로드되었을 때 필요한 초기화 작업
        if (!IsPostBack)
        {
            // 세션에 "LoggedIn" 값이 true인지 확인하여 로그인된 상태인지 체크
            if (Session["LoggedIn"] == null || (bool)Session["LoggedIn"] == false)
            {
                Response.Redirect("Login.aspx"); // 로그인되지 않은 경우 로그인 페이지로 리디렉션
            }
        }
    }
}