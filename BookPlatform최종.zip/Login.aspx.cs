﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI;
using System.Web.Security;

public partial class Login : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            // 로그인된 상태
            btnLogin.Visible = false;  // 로그인 버튼 숨기기
            btnLogout.Visible = true;  // 로그아웃 버튼 표시
        }
        else
        {
            // 로그인되지 않은 상태
            btnLogin.Visible = true;  // 로그인 버튼 표시
            btnLogout.Visible = false;  // 로그아웃 버튼 숨기기
        }
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string username = txtUsername.Text.Trim(); // 입력된 사용자 이름
        string password = txtPassword.Text.Trim(); // 입력된 비밀번호

        // 입력한 아이디와 비밀번호가 sa와 65876587인지 확인
        if (username == "sa" && password == "65876587")
        {
            // 로그인 성공 시 세션에 정보 저장
            Session["LoggedIn"] = true;
            Response.Redirect("AdminPage.aspx"); // 로그인 성공 시 관리자 페이지로 이동
        }
        else
        {
            // 로그인 실패 시 메시지 출력
            lblMessage.Text = "아이디 또는 비밀번호가 잘못되었습니다.";
        }

        // 사용자 인증
        if (IsValidUser(username, password))
        {
            // 로그인 성공 시 세션에 사용자 정보 저장
            Session["UserID"] = username;
            Session["LoggedIn"] = true;
            Response.Redirect("MainPage.aspx"); // 로그인 후 이동할 페이지
        }
        else
        {
            // 로그인 실패 시 메시지 표시
            lblMessage.Text = "아이디 또는 비밀번호가 잘못되었습니다.";
        }
    }


    private bool IsValidUser(string username, string password)
    {
        // 데이터베이스 연결 문자열
        string connectionString = ConfigurationManager.ConnectionStrings["ASPNET"].ConnectionString;

        // 사용자 인증을 위한 SQL 쿼리 (aspnet_Membership에서 사용자 및 비밀번호 확인)
        string query = "SELECT UserId FROM aspnet_Users WHERE Username = @Username";

        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            try
            {
                conn.Open();

                // SQL Command 객체 생성
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    // 파라미터 추가
                    cmd.Parameters.AddWithValue("@Username", username);

                    // 사용자 ID를 가져오기
                    object userId = cmd.ExecuteScalar();

                    string storedPasswordHash = cmd.ExecuteScalar() as string;

                    if (userId != null)
                    {
                        // 비밀번호를 검증하는 Membership.Provider의 ValidateUser 사용
                        bool isValid = Membership.ValidateUser(username, password);
                        return isValid;
                    }

                    return false;
                }
            }
            catch (Exception ex)
            {
                // 예외 처리: DB 연결 실패 또는 다른 오류 발생 시
                lblMessage.Text = "로그인 처리 중 오류가 발생했습니다: " + ex.Message;
                return false;
            }
        }
    }


    protected void btnRegister_Click(object sender, EventArgs e)
    {
        // 회원가입 페이지로 리다이렉트
        Response.Redirect("Register.aspx"); // 회원가입 페이지의 URL로 변경
    }

    // 로그아웃 버튼 클릭 이벤트 처리
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Clear();  // 세션 종료
        Response.Redirect("Login.aspx");  // 로그인 페이지로 리디렉션
    }
}
