﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Public_Register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    // 계속 버튼 클릭 이벤트 처리
    protected void CreateUserWizard1_ContinueButtonClick(object sender, EventArgs e)
    {
        // 로그인 페이지로 리다이렉트
        Response.Redirect("~/Login.aspx");
    }
}