﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

public partial class Recommend : System.Web.UI.Page
{
    // 연결 문자열을 웹.config에서 가져옴
    private string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["ASPNET"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // 책 목록을 DB에서 가져오기
            LoadBooks();
        }
    }

    private void LoadBooks()
    {
        List<Book> books = new List<Book>();

        string query = "SELECT [BookID], [Title], [Author], [ImagePath], [Url] FROM [Books] ORDER BY [BookID]";
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            SqlCommand cmd = new SqlCommand(query, conn);
            conn.Open();

            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Book book = new Book
                {
                    Title = reader["Title"].ToString(),
                    Author = reader["Author"].ToString(),
                    ImagePath = reader["ImagePath"].ToString(),
                    Url = reader["Url"].ToString() // URL 값도 추가
                };
                books.Add(book);
            }
        }

        // 디버깅 로그 추가: books 데이터 확인
        System.Diagnostics.Debug.WriteLine("Total Books: " + books.Count);

        BooksRepeater.DataSource = books;
        BooksRepeater.DataBind();
    }

    // Book 클래스 정의
    public class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public string ImagePath { get; set; }
        public string Url { get; set; } // URL을 추가
    }
}
