﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class AddBook : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnAddBook_Click(object sender, EventArgs e)
    {
        string title = txtTitle.Text;
        string author = txtAuthor.Text;
        string imagePath = txtImagePath.Text;
        string comment = txtComment.Text;

        string connString = System.Configuration.ConfigurationManager.ConnectionStrings["ASPNET"].ToString();
        using (SqlConnection conn = new SqlConnection(connString))
        {
            string query = "INSERT INTO Books (Title, Author, ImagePath,  Comment) VALUES (@Title, @Author, @ImagePath, @Comment)";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Title", title);
            cmd.Parameters.AddWithValue("@Author", author);
            cmd.Parameters.AddWithValue("@ImagePath", imagePath);
            cmd.Parameters.AddWithValue("@Comment", comment);

            conn.Open();
            cmd.ExecuteNonQuery();
        }
    }
}