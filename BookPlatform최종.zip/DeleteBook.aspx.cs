﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class DeleteBook : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        LoadBooks();
    }

    private void LoadBooks()
    {
        string connString = System.Configuration.ConfigurationManager.ConnectionStrings["ASPNET"].ToString();
        using (SqlConnection conn = new SqlConnection(connString))
        {
            string query = "SELECT BookID, Title, Author FROM Books";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            System.Data.DataTable dt = new System.Data.DataTable();
            da.Fill(dt);
            gvBooks.DataSource = dt;
            gvBooks.DataBind();
        }
    }

    protected void gvBooks_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int bookId = Convert.ToInt32(gvBooks.DataKeys[e.RowIndex].Value);
        DeleteBookById(bookId);
        LoadBooks();
    }

    public void DeleteBookById(int bookId)
    {
        string connString = System.Configuration.ConfigurationManager.ConnectionStrings["ASPNET"].ToString();
        using (SqlConnection conn = new SqlConnection(connString))
        {
            string query = "DELETE FROM Books WHERE BookID = @BookID";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@BookID", bookId);
            conn.Open();
            cmd.ExecuteNonQuery();
        }
    }
}