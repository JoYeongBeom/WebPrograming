﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class CommentManagement : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadComments();
        }
    }

    private void LoadComments()
    {
        string connStr = System.Configuration.ConfigurationManager.ConnectionStrings["ASPNET"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            string query = "SELECT id, comment, created_at FROM comments ORDER BY created_at DESC";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            gvComments.DataSource = dt;
            gvComments.DataBind();
        }
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        Button btnDelete = (Button)sender;
        int commentId = Convert.ToInt32(btnDelete.CommandArgument);

        string connStr = System.Configuration.ConfigurationManager.ConnectionStrings["ASPNET"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connStr))
        {
            string query = "DELETE FROM comments WHERE id = @id";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@id", commentId);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        LoadComments(); // 삭제 후 댓글 목록 다시 로드
    }
}