﻿using System;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Web.UI.WebControls;
using System.Configuration;

public partial class index : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // URL에서 bookId 파라미터 가져오기
            string bookId = Request.QueryString["bookId"];

            if (!string.IsNullOrEmpty(bookId))
            {
                LoadBookDetails(int.Parse(bookId));
            }

            LoadComments();
        }

    }

    private void LoadBookDetails(int bookId)
    {

        string connectionString = ConfigurationManager.ConnectionStrings["ASPNET"].ConnectionString;
        string query = "SELECT Title, Author, ImagePath, Comment, AVG(Rating) AS AverageRating FROM Books WHERE BookID = @BookID GROUP BY Title, Author, ImagePath, Comment";
        string ratingQuery = "SELECT AVG(Rating) AS AverageRating FROM BookRatings WHERE BookID = @BookID";

        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@BookID", bookId);

            try
            {
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    // 책 정보 로드
                    string imagePath = reader["ImagePath"].ToString();
                    string title = reader["Title"].ToString();
                    string comment = reader["Comment"].ToString();

                    // 이미지 경로와 코멘트 표시
                    BookImage.Src = imagePath;
                    BookTitle.InnerText = title;
                    BookComment.InnerText = comment;
                }
                reader.Close();  // 반드시 닫기

                // 평균 별점 계산
                SqlCommand ratingCmd = new SqlCommand(ratingQuery, conn);
                ratingCmd.Parameters.AddWithValue("@BookID", bookId);
                object avgRatingResult = ratingCmd.ExecuteScalar();

                if (avgRatingResult != DBNull.Value)
                {
                    double averageRating = Convert.ToDouble(avgRatingResult);
                    DisplayAverageRating(averageRating);
                }
                else
                {
                    DisplayAverageRating(0);  // 별점이 없으면 0으로 표시
                }
            }
            catch (Exception ex)
            {
                // 오류 처리
                Response.Write("Error: " + ex.Message);
            }
        }
    }

    protected void btnSubmitRating_Click(object sender, EventArgs e)
    { 
        // URL에서 bookId 가져오기
        string bookIdString = Request.QueryString["bookId"];

        // bookId를 정수로 변환할 변수 선언
        int bookId;

        // bookId가 유효한지 확인
        if (string.IsNullOrEmpty(bookIdString) || !int.TryParse(bookIdString, out bookId))
        {
            Response.Write("유효한 책 ID가 아닙니다.");
            return;
        }

        // 선택된 별점 가져오기
        int rating = GetSelectedRating();

        // 별점이 선택된 경우 DB에 저장
        if (rating > 0)
        {
            SaveRating(bookId, rating);
        }
        else
        {
            Response.Write("별점을 선택해주세요.");
        }
    }

    private int GetSelectedRating()
    {
        if (star1.Checked) return 1;
        if (star2.Checked) return 2;
        if (star3.Checked) return 3;
        if (star4.Checked) return 4;
        if (star5.Checked) return 5;
        return 0;  // 선택되지 않았으면 0 반환
    }

    private void SaveRating(int bookId, int rating)
    {
        string connectionString = ConfigurationManager.ConnectionStrings["ASPNET"].ConnectionString;
        string query = "INSERT INTO BookRatings (BookID, Rating) VALUES (@BookID, @Rating)";

        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Rating", rating);
            cmd.Parameters.AddWithValue("@BookID", bookId);

            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();  // 별점 저장
            }
            catch (Exception ex)
            {
                Response.Write("Error: " + ex.Message);
            }
        }
    }

    private void DisplayAverageRating(double averageRating)
    {
        // 예시로 별점 표시: 실제로는 UI에서 원하는 형식으로 표시할 수 있음
        string stars = new string('★', (int)averageRating);
        AverageRatingLabel.Text = "평균 별점: " + stars;
    }


    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        // 댓글 작성 처리
        string comment = txtComment.Text.Trim();

        if (string.IsNullOrEmpty(comment))
        {
            // 댓글 내용이 비어있으면 경고 메시지 출력
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('댓글 내용을 입력해주세요.');", true);
            return;
        }

        string bookId = Request.QueryString["bookId"];
        if (string.IsNullOrEmpty(bookId))
        {
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('책 ID가 존재하지 않습니다.');", true);
            return;
        }

        string connectionString = WebConfigurationManager.ConnectionStrings["ASPNET"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            string query = "INSERT INTO comments (comment, created_at, BookID) VALUES (@comment, @created_at, @BookID)";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@comment", comment);
            cmd.Parameters.AddWithValue("@created_at", DateTime.Now);
            cmd.Parameters.AddWithValue("@BookID", bookId); // 책 ID 추가

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        // 댓글 작성 후 페이지 새로고침
        Response.Redirect(Request.RawUrl);
    }

    // 댓글 리스트를 로드하는 메소드
    private void LoadComments()
    {
        string connectionString = WebConfigurationManager.ConnectionStrings["ASPNET"].ConnectionString;
        string query = "SELECT [id], [comment], [created_at] FROM [comments] ORDER BY [created_at] DESC";

        using (SqlConnection conn = new SqlConnection(connectionString))
        {
            SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
            System.Data.DataTable dt = new System.Data.DataTable();
            adapter.Fill(dt);

            // GridView에 데이터를 바인딩
          
            gvComments.DataBind();
        }
    }
}
