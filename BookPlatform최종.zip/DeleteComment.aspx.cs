﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class DeleteComment : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // 댓글 정보 표시
            string comment = Request.QueryString["comment"];
            string createdAt = Request.QueryString["created_at"];

            // 화면에 댓글 내용과 작성 날짜를 표시
            // 필요시, 이를 기반으로 삭제 처리
        }
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        string comment = Request.QueryString["comment"];

        // 댓글 삭제
        DeleteCommentFromDB(comment);

        // 삭제 후 목록 페이지로 리다이렉트
        Response.Redirect("AdminPage.aspx");
    }

    private void DeleteCommentFromDB(string comment)
    {
        string connString = System.Configuration.ConfigurationManager.ConnectionStrings["ASPNET"].ToString();

        using (SqlConnection conn = new SqlConnection(connString))
        {
            string query = "DELETE FROM comments WHERE comment = @Comment";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Comment", comment);

            conn.Open();
            cmd.ExecuteNonQuery();
        }
    }
}